# Install Dependecies
npm install express pg dotenv joi bcrypt jsonwebtoken
npm install -D nodemon eslint node-pg-migrate
npm init @eslint/config
npm install --save-dev eslint@8 eslint-config-dicodingacademy